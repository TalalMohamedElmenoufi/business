<?php
if($_POST){
	$email = $_POST[email];
	$senha = $_POST[senha];
	$numbers = $_POST[numeros]; //Apenas os 11 numeros, retirar o numero '9' exemplo '559284914625,559291725319'
	$mensagem = $_POST[mensagem];
	
	EnviarWhats($email,$senha,$numbers,$mensagem);
}
 
function EnviarWhats($email,$senha,$numeros,$mensagem){
	
	$fields = array
	(
			'email' => $email,
			'senha' => $senha,
			'numeros' => $numeros,
			'mensagem' => $mensagem
	);

	$headers = array
	(
	'Content-Type: application/json'
	);

	
	echo json_encode( $fields )."<br>";
	
	$ch = curl_init();
	curl_setopt( $ch,CURLOPT_URL, 'https://elmenoufi.com.br/business/integracao/send.php' );
	curl_setopt( $ch,CURLOPT_GET, true );
	curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
	curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
	curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
	curl_setopt( $ch,CURLOPT_FOLLOWLOCATION, true);	
	$result = curl_exec($ch );
	curl_close( $ch );

	echo $result;
}



?>

<form action="modelo_send.php" method="post" enctype="multipart/form-data" >
	
	<input type="text" name="email" placeholder="nome@dominio.com.br" />
	<input type="text" name="senha" placeholder="Sua senha de autenticação" />
	<input type="text" name="numeros" placeholder="559284914625,559291725319" />
	<input type="text" name="mensagem" placeholder="HELO WORD API" />
	
	<input type="submit" name="Enviar" value="Enviar" />
	
</form>