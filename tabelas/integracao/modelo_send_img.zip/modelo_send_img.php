<?php
function acentos($palavra){
	$acentos = array(
		 'á' => 'a', 'à' => 'a', 'ã' => 'a', 'â' => 'a', 'é' => 'e', 'ê' => 'e', 'í' => 'i', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ú' => 'u', 'ü' => 'u', 'ç' => 'c', 'Á' => 'A', 'À' => 'A', 'Ã' => 'A', 'Â' => 'A', 'É' => 'E', 'Ê' => 'E', 'Í' => 'I', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ú' => 'U', 'Ü' => 'U', 'Ç' => 'C');
	$acao = strtr($palavra, $acentos);
	return $acao ;
}

function RetiraEspaco($espaco){
 $acao = str_replace(' ', '_', $espaco);
 return $acao ;
}

$trat = RetiraEspaco($_FILES['arquivo_img']['name']) ;
$arquivo_img = date('YmdHis')."_".acentos($trat) ;


if($_POST){
	
	$ultimos4 = substr($arquivo_img , -4);

	if($ultimos4 == '.png' or $ultimos4 == '.PNG' or $ultimos4 == '.jpg' or  $ultimos4 == '.JPG' ){
		$img_ext_file = substr($ultimos4, 1);
	}elseif($ultimos4 == 'JPEG' or $ultimos4 == 'jpeg'){
		$img_ext_file = $ultimos4;
	}

	$uploaddir = './upload/';
	move_uploaded_file($_FILES['arquivo_img']['tmp_name'], $uploaddir.$arquivo_img);
	if(($_FILES['arquivo_img']['name'])){
	$img = $arquivo_img;
	$img_ext = $img_ext_file;

	}else{
	$img = '';
	$img_ext = '' ;			
	}
	
	$caminho_img = 'public_html-seusite-upload'; //cainho abesoluto 'Cada pasta separada por - conforme o exemplo'
	
	$email = $_POST[email];
	$senha = $_POST[senha];
	$numbers = $_POST[numeros]; //Apenas os 11 numeros, retirar o numero '9' exemplo '559284914625,559291725319'
	$mensagem = $_POST[mensagem];
	
	EnviarWhats($email,$senha,$numbers,$mensagem,$caminho_img,$img,$img_ext);
}
 
function EnviarWhats($email,$senha,$numeros,$mensagem,$caminho_img,$img,$img_ext){
	
	$fields = array
	(
			'email' => $email,
			'senha' => $senha,
			'numeros' => $numeros,
			'mensagem' => $mensagem,
			'caminho_img' => $caminho_img,
			'img' => $img,
			'img_ext' => $img_ext
	);

	$headers = array
	(
	'Content-Type: application/json'
	);

	
	echo json_encode( $fields )."<br>";
	
	$ch = curl_init();
	curl_setopt( $ch,CURLOPT_URL, 'https://elmenoufi.com.br/business/integracao/image.php' );
	curl_setopt( $ch,CURLOPT_GET, true );
	curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
	curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
	curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
	curl_setopt( $ch,CURLOPT_FOLLOWLOCATION, true);	
	$result = curl_exec($ch );
	curl_close( $ch );

	echo $result;
}



?>

<form action="modelo_send_img.php" method="post" enctype="multipart/form-data" >
	
	<input type="text" name="email" placeholder="nome@dominio.com.br" /><br>
	<input type="text" name="senha" placeholder="Sua senha de autenticação" /><br>
	<input type="text" name="numeros" placeholder="559284914625,559291725319" /><br>
	<input type="text" name="mensagem" placeholder="HELO WORD API" /><br>
	<input type="file" name="arquivo_img" /><br>
	<input type="submit" name="Enviar" value="Enviar" />
	
</form>